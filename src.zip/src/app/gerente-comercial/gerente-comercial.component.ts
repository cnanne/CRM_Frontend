import { Component } from '@angular/core';
import { SharedFrameModule } from "../shared-frame/shared-frame.module";

@Component({
  selector: 'app-gerente-comercial',
  templateUrl: './gerente-comercial.component.html',
  styleUrl: './gerente-comercial.component.css'
})
export class GerenteComercialComponent {

}
