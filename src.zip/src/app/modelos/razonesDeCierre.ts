import { EstadoMacro1 } from "./estadoOpp";

export interface RazonDeCierre {
    id: number;
    nombre: string;
    tipoDeCierre: EstadoMacro1;
}