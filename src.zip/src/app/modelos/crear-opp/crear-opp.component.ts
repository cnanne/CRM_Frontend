import { Component } from '@angular/core';

@Component({
  selector: 'app-crear-opp',
  standalone: true,
  imports: [],
  templateUrl: './crear-opp.component.html',
  styleUrl: './crear-opp.component.css'
})
export class CrearOppComponent {

}
