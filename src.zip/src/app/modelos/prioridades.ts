export interface Prioridad{
    id?: number
    nombre?: string
    value?: number
}