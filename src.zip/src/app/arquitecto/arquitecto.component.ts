import { Component } from '@angular/core';

@Component({
  selector: 'app-arquitecto',
  standalone: true,
  imports: [],
  templateUrl: './arquitecto.component.html',
  styleUrl: './arquitecto.component.css'
})
export class ArquitectoComponent {

}
