export interface SharedFrameDynamicComponent {
}
