import { DynamicContentAreaDirective,  } from './dynamic-content-area.directive';
import { ViewContainerRef } from '@angular/core';

describe('DynamicContentAreaDirective', () => {
  it('should create an instance', () => {
   // const directive = new DynamicContentAreaDirective();
   // expect(directive).toBeTruthy();
  });
});
