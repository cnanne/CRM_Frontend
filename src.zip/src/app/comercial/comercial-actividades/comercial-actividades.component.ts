import { Component } from '@angular/core';
import { SharedFrameDynamicComponent } from '../../shared-frame/shared-frame.component';

@Component({
  selector: 'app-comercial-actividades',
  templateUrl: './comercial-actividades.component.html',
  styleUrl: './comercial-actividades.component.css'
})
export class ComercialActividadesComponent implements SharedFrameDynamicComponent{

}
