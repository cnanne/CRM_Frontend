import { Component } from '@angular/core';
import { SharedFrameDynamicComponent } from '../../shared-frame/shared-frame.component';

@Component({
  selector: 'app-comercial-oportunidades',
  templateUrl: './comercial-oportunidades.component.html',
  styleUrl: './comercial-oportunidades.component.css'
})
export class ComercialOportunidadesComponent implements SharedFrameDynamicComponent{

}
