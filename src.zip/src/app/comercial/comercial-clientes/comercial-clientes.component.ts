import { Component } from '@angular/core';
import { SharedFrameDynamicComponent } from '../../shared-frame/shared-frame.component';

@Component({
  selector: 'app-comercial-clientes',
  templateUrl: './comercial-clientes.component.html',
  styleUrl: './comercial-clientes.component.css'
})
export class ComercialClientesComponent implements SharedFrameDynamicComponent{

}
